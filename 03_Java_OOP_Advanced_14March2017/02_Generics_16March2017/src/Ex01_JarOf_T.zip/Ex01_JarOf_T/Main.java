package Ex01_JarOf_T;


public class Main {
    public static void main(String[] args) {
        Jar<String> jar = new Jar<>();

    }
}
