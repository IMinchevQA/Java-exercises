package Ex07_EqualityLogic;


public interface Person {

    String getName();

    int getAge();
}
