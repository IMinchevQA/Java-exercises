package Ex06_StrategyPattern;

public interface Person {

    String getName();

    int getAge();
}
