package Ex02_GenericBoxOfInteger;

public interface Box<P> {

    @Override
    String toString();
}
