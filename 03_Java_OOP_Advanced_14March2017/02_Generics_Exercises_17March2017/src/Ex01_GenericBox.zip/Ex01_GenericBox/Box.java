package Ex01_GenericBox;


public interface Box<P> {

    @Override
    String toString();
}
