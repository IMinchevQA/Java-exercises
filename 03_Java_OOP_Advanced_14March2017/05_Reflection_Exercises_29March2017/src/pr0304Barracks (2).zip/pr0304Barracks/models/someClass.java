package pr0304Barracks.models;

/**
 * Created by Ivan Minchev on 3/30/2017.
 */
public class someClass {
}
