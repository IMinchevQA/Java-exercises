package Ex08_MilitaryElite_15March2017.interfaces;

public interface SpecialisedSoldier extends Soldier {
    String getCorps();
}
