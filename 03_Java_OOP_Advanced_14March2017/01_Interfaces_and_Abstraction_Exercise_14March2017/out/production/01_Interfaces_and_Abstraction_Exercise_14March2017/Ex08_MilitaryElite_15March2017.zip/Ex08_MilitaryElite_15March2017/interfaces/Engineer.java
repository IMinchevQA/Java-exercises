package Ex08_MilitaryElite_15March2017.interfaces;



import java.util.Collection;

public interface Engineer {
    Collection<Repair> getRepairs();
}
