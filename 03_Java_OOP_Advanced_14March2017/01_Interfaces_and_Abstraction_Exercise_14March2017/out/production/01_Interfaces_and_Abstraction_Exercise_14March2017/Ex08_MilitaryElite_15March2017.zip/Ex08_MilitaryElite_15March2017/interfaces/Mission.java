package Ex08_MilitaryElite_15March2017.interfaces;

public interface Mission {
    String getCodeName();
    String getState();
    void completeMission();
}
