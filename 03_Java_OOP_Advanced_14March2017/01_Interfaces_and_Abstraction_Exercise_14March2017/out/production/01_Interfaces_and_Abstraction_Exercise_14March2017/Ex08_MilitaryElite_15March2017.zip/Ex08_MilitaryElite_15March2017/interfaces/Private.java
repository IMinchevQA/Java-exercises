package Ex08_MilitaryElite_15March2017.interfaces;


public interface Private {
    double getSalary();
}
