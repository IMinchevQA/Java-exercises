package Ex08_MilitaryElite_15March2017.interfaces;

public interface Repair {
    String getPartName();
    int getHours();
}
