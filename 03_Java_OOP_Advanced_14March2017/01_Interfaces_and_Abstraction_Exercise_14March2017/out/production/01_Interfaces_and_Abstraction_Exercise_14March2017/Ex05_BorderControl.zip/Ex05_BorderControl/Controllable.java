package Ex05_BorderControl;

public interface Controllable {
    String getName();
    String getModel();
    String getAge();
    String getId();
}
