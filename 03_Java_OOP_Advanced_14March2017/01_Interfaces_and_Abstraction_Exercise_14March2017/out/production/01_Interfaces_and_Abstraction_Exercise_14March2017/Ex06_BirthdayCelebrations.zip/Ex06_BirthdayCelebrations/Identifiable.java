package Ex06_BirthdayCelebrations;

public interface Identifiable {
    String getName();
    String getAge();
    String getId();
}
