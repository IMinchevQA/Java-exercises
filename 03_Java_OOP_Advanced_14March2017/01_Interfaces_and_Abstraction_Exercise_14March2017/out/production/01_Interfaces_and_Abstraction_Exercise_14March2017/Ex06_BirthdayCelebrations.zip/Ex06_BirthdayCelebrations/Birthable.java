package Ex06_BirthdayCelebrations;

public interface Birthable {
    String getBirthday();
}
