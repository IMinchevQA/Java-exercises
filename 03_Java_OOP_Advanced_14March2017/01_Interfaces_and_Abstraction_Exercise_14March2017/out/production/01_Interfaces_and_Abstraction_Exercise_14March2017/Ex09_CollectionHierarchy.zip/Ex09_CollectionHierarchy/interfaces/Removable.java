package Ex09_CollectionHierarchy.interfaces;


public interface Removable extends Addable {
    String remove();
}
