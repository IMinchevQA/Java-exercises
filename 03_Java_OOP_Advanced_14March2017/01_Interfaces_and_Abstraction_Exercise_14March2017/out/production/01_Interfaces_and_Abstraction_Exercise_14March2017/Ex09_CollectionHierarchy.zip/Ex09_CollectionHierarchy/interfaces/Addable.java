package Ex09_CollectionHierarchy.interfaces;

public interface Addable {
    int add(String string);
}
