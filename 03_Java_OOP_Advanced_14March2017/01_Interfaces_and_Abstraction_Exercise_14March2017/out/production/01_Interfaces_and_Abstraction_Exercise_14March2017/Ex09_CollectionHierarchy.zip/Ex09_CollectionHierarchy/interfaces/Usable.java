package Ex09_CollectionHierarchy.interfaces;

public interface Usable extends Addable, Removable {
    int used();
}
