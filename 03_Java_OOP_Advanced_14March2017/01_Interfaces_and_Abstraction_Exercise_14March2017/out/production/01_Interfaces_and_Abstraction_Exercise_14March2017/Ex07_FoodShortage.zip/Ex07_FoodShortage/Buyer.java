package Ex07_FoodShortage;

public interface Buyer {
    int getFood();

    void buyFood();
}
