package Ex01_DefineAnInterfacePerson_15March2017;

public interface Person {
    String getName();
    int getAge();

}
