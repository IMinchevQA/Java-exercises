package Ex03_Ferrari;


public interface Car {
    String getModel();
    String getName();
    String brakes();
    String gasPedal();
}
