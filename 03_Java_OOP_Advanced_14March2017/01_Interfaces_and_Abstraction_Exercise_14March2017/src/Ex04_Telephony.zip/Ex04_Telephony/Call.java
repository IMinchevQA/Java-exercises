package Ex04_Telephony;


public interface Call {
    String[] getPhoneNumbers();
}
