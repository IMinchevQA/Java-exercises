package Ex04_Telephony;

public interface Browse {
    String[] getSites();
}
