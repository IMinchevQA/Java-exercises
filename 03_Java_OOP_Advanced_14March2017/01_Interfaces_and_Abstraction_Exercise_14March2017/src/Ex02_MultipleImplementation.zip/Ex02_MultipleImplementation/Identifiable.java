package Ex02_MultipleImplementation;

public interface Identifiable {
    String getId();
}
