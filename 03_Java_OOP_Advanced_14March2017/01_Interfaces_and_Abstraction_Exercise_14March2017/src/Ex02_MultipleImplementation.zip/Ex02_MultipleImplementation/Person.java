package Ex02_MultipleImplementation;

public interface Person {
    String getName();
    int getAge();

}
