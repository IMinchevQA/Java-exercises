package Ex10_InfernoInfinity.interfaces;

public interface Gem {
    int getBonusStrength();
    int getBonusAgility();
    int getBonusVitality();
}
