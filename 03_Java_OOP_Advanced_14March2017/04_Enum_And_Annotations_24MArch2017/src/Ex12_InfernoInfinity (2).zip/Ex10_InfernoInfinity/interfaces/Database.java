package Ex10_InfernoInfinity.interfaces;

public interface Database {
    void addWeapon(Weapon weapon);
    Weapon getWeapon(String name);
}
