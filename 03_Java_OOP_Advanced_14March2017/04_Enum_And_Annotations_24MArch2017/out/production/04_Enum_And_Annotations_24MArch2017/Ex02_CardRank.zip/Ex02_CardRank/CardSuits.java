package Ex02_CardRank;

public enum CardSuits {
     CLUBS, DIAMONDS, HEARTS, SPADES
}
