package Ex10_InfernoInfinity.implementations;

public class Emerlad extends GemImpl {
    private static final int DEFAULT_STRENGTH = 1;
    private static final int DEFAULT_AGILITY = 4;
    private static final int DEFAULT_VITALITY = 9;

    public Emerlad() {
    super(DEFAULT_STRENGTH, DEFAULT_AGILITY, DEFAULT_VITALITY);
    }
}
