package Ex09_TrafficLights;


public enum Signals {
    RED,
    GREEN,
    YELLOW
}
