package Ex01_CardSuits;

public enum CardSuits {
     CLUBS, DIAMONDS, HEARTS, SPADES
}
