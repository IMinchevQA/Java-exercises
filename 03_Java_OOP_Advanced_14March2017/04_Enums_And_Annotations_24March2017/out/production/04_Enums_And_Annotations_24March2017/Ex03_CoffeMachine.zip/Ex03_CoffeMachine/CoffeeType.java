package Ex03_CoffeMachine;


public enum  CoffeeType {
    ESPRESSO, LATTE, IRISH;
}
