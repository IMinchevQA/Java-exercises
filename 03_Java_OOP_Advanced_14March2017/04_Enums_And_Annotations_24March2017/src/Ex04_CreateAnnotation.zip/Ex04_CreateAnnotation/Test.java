package Ex04_CreateAnnotation;

@Subject(categories = {"Test", "Annotations"})
public class Test {
}
