package Ex01_Weekdays;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.stream.Stream;

public class Main {
    enum Season {
        SPRING, SUMMER, AUTUMN, WINTER
    }
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    }
}
