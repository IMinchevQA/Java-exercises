//package someCrazyReflection;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) throws IllegalAccessException, InstantiationException {
//        //Ex.1 : Reflection
//        Class reflectionClass = Reflection.class;
//        System.out.println(reflectionClass);
//
//        Class superClass = reflectionClass.getSuperclass();
//        System.out.println(superClass);
//
//        Class[] reflectionClassInterfaces = reflectionClass.getInterfaces();
//        Stream.of(reflectionClassInterfaces).forEach(i -> System.out.println(i));
//
//        Reflection reflection = (Reflection) reflectionClass.newInstance();
//        System.out.println(reflection);


        //Ex.2: Getters and Setters
        Class reflectionClass = Reflection.class;
        Method[] allMethods = reflectionClass.getDeclaredMethods();

        Method[] allGetters = Stream.of(allMethods).filter(e -> e.getName().startsWith("get")).toArray(g -> new Method[g]);

        Method[] allSetters = Stream.of(allMethods).filter(e -> e.getName().startsWith("set")).toArray(s -> new Method[s]);

        Arrays.sort(allGetters, Comparator.comparing(m -> m.getName()));
        Stream.of(allGetters).forEach(g -> System.out.println(String.format("%s will return %s",
                g.getName(), g.getReturnType())));

        Arrays.sort(allSetters, Comparator.comparing(m -> m.getName()));
        Stream.of(allSetters).forEach(s -> {
            if (void.class.equals(s.getReturnType())) {
                if (s.getParameterCount() == 1) {
                    System.out.println(String.format("%s and will set field of %s",
                            s.getName(), s.getParameterTypes()[0]));
                }
            }
        });
    }
}
