//package someCrazyReflection;

import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) throws IllegalAccessException, InstantiationException {
        //Ex.1
        Class reflectionClass = Reflection.class;
        System.out.println(reflectionClass);

        Class superClass = reflectionClass.getSuperclass();
        System.out.println(superClass);

        Class[] reflectionClassInterfaces = reflectionClass.getInterfaces();
        Stream.of(reflectionClassInterfaces).forEach(i -> System.out.println(i));

        Reflection reflection = (Reflection) reflectionClass.newInstance();
        System.out.println(reflection);

    }
}
