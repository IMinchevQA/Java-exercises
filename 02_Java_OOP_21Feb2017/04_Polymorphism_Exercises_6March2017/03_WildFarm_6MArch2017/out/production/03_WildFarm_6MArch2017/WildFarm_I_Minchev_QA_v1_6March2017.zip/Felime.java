
public abstract class Felime extends Mammal {

    public Felime(String animalName, double animalWeight, String animalLivingRegion) {
        super.setAnimalName(animalName);
        super.setAnimalWeight(animalWeight);
        super.setAnimalLivingRegion(animalLivingRegion);
    }
}
