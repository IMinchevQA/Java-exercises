/**
 * Created by Ivan Minchev on 2/23/2017.
 */
public class Person {
    String name;
    int age;
    public Person () {
        this(1, "No name");
    }

    public Person (int age) {
        this(age, "No name");
    }

    public Person (int age, String name) {
        this.age = age;
        this.name = name;
    }
}
