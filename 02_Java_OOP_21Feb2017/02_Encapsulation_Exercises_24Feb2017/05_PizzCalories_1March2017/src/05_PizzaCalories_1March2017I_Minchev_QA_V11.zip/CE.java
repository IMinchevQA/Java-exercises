
public class CE extends IllegalArgumentException {
    public CE (String message) {
        super(message);
    }
}
