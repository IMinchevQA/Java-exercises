/**
 * Created by Ivan Minchev on 3/2/2017.
 */
public class Cat extends Animal {
    public void meow() {
        System.out.println("meowing...");
    }
}
