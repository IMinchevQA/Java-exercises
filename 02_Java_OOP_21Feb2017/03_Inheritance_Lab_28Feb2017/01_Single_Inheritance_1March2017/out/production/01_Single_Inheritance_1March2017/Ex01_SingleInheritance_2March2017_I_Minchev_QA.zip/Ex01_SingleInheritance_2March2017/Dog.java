package Ex01_SingleInheritance_2March2017;

public class Dog extends Animal {

    public void bark() {
        System.out.println("barking...");
    }

}
