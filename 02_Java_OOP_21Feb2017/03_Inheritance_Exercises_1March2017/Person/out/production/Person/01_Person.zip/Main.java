
public class Main {
    public static void main(String[] args) {

        try {
            Child child = new Child("sho", 15);
            System.out.println(child.toString());
        } catch (IllegalArgumentException iae) {
            System.out.println(iae.getMessage());
            return;
        }
    }
}
